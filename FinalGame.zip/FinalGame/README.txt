This is the code base to be used in the creation of the final game:

If your reading this then just note what parts you have added onto the file
that way we won't get so confused with eachothers parts wer plan on making

Max's parts:
_object_max.h/.cpp		I used this to create various objects
_objectinteract_max.h/.cpp  	then I used this to update their information using different seperate static cases (it includes gl_push,gl_pop matrix with its functionality so no need to include that in scene if oyu are using my object type)
_movement_max.h/.cp		This was used for updating the movement of various things in relation to the world
_hitbox_max.h/.cpp		a simple hitbox class for calculating the hitbox of objects in relation to one another (note the hitbox is kinda buggy, it works but is slightly miscalcualted)
_healthpack_max.h/.cpp		a simple in game object that can be interacted with
_animate_max.h/.cpp		a simple class to animate various objects in the game

Emmanuel's parts:
Testing a push from me.

_mainScene.h/.cpp 		I plan on using this to create all the buttons for the main menu/scene. To do this I create a quadrant then bind a texture to it
				with the texture class. Then using the GetOGLPos() function i get the coordinates of the mouse click and as long as that mouse 
				click is within the range of the quadrant it will run the button's functionalities.


Eric's parts:
_collision			I was able to make a small portion of collision. It should help with walls and floors
_weapons			Trying to implement the weapons that we can use. Also include's the physics of the bullets.
Don's parts: