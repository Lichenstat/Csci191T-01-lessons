#ifndef _GLSCENE_H
#define _GLSCENE_H

#include <windows.h>
#include <GL/glut.h>
#include <iostream>
#include <_model.h>
#include <_input.h>
#include <_texture.h>
#include <_parallax.h>
#include <_menu.h>

using namespace std;


class _glScene
{
    public:
        _glScene();
        virtual ~_glScene();

        GLint initGL();
        GLint drawScene();
        void resizeGLScene(int,int);

        bool doneLoading;
        float screenWidth,screenHeight;

        // current game state
        enum cgs {landing, menu, play, help};
        cgs state=landing;

        _model *myModel = new _model();
        _input *kbMs = new _input();
        _texture *modelTex = new _texture();
        _parallax *background = new _parallax();
        _parallax *background1 = new _parallax();

        _menu *Menu = new _menu();
        _menu *Landing = new _menu();
        _menu *Help = new _menu();
        _menu *Play = new _menu();



        int winMsg(HWND,UINT,WPARAM,LPARAM);
        WPARAM wParam;

    protected:

    private:

};

#endif // _GLSCENE_H
