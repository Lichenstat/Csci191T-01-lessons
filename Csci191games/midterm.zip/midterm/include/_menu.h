#ifndef _MENU_H
#define _MENU_H

#include<string>
#include<GL/gl.h>
#include<_texture.h>

class _menu
{
    public:
        _menu();
        virtual ~_menu();
        void menuInit(char *);
        void drawMenu(double, double);

        double xMin, xMax, yMin, yMax;

        //_texture *menuTexture = new _texture();

    protected:

    private:

};

#endif // _MENU_H
