#include "_menu.h"

#include "_model.h"
#include<_texture.h>

_texture *mTex = new _texture();

_menu::_menu()
{
    //ctor
    xMin = 0.0;
    xMax = 1.0;
    yMin = 1.0;
    yMax = 0.0;


}


void _menu::menuInit(char* filename)
{
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    mTex->TextureBinder();
    mTex->loadTexture(filename);
}

_menu::~_menu()
{
    //dtor
}
void _menu::drawMenu(double w, double h)
{

    glColor3f(1.0,1.0,1.0);
    mTex->TextureBinder();

    glBegin(GL_POLYGON);

    glTexCoord2f(xMin,yMin); glVertex3f(-w/h, -1, 0);
    glTexCoord2f(xMax, yMin); glVertex3f(w/h, -1, 0);
    glTexCoord2f(xMax, yMax); glVertex3f(w/h, 1, 0);
    glTexCoord2f(xMin, yMax); glVertex3f(-w/h, 1, 0);

    glEnd();
}
