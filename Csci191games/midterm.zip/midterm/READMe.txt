Midterm Submission for 191T
This program starts by displaying a landing page, if �Enter� or Left mouse button is clicked, it goes to the menu page. The menu items �New Game�, �Help�, �Exit� can be selected by the first letter. If �New Game� is selected, it goes to �Play� state and during this state, if �Esc� is pressed, people can select �Yes� to quit or �Esc� to stay in the game.

Dong Lin
